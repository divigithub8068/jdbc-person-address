package com.ty.person.util;

public interface AppConstants 
{
	String URL ="jdbc:mysql://localhost:3306/jdbc_person_address";
	String DRIVER= "com.mysql.cj.jdbc.Driver";
	String USER = "root";
	String PASSWORD = "Prashi@123";
	
	String SECRETE_KEY = "prashi";
}
